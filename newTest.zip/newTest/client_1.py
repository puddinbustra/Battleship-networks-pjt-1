'''
Created on Sep 20, 2018

@author: andrewdixon
'''
# Import socket module

import requests


data = "x=5&y=7"
params = "x=5&y=7"

r = requests.post('http://127.0.0.1:12345/', data, params = params)
print(r.url)

print(r.text)
